package conf

// redis配置
//@author Zhiqiang Guo
var Redis = map[string]string{
	"name":    "redis",
	"type":    "tcp",
	"address": "127.0.0.1:6379",
	"auth":    "",
}
