package lang
var en= map[string]string{

}